/*
 * mainGame.cpp
 *
 *  Created on: Feb 22, 2023
 *     Author: Furdeen Hasan and Lizzy Kalfas
 */

#include "Board.hpp"
#include "Dog.hpp"
#include <iostream>
#include <time.h>
#include <stdlib.h>
using namespace std;


int main() {
	srand(time(NULL));
	Board board('m',"Spot", true);
	return 0;
}


